import numpy as np

# Task 9: Eigenvalues and Eigenvectors
# Application: Eigenvector-based importance in a small network.

A = np.array([
    [0., 1., 1., 0.],
    [1., 0., 1., 1.],
    [1., 1., 0., 1.],
    [0., 1., 1., 0.]
])

eigenvalues, eigenvectors = np.linalg.eig(A)

index = np.argmax(np.real(eigenvalues))
dominant_value = np.real(eigenvalues[index])
dominant_vector = np.abs(np.real(eigenvectors[:, index]))

centrality = dominant_vector / dominant_vector.sum()
nodes = ["A", "B", "C", "D"]

print("All eigenvalues:", np.real(eigenvalues))
print("Dominant eigenvalue:", dominant_value)
print("Eigenvector-based importance:")

for node, score in zip(nodes, centrality):
    print(f"{node}: {score:.4f}")

v = np.real(eigenvectors[:, index])
print("Verification error:",
      np.linalg.norm(A @ v - dominant_value * v))

# Parameter change example: add a connection between A and D.
A_changed = A.copy()
A_changed[0, 3] = 1
A_changed[3, 0] = 1

values2, vectors2 = np.linalg.eig(A_changed)
idx2 = np.argmax(np.real(values2))
centrality2 = np.abs(np.real(vectors2[:, idx2]))
centrality2 /= centrality2.sum()

print("\nAfter adding a connection between A and D:")
for node, score in zip(nodes, centrality2):
    print(f"{node}: {score:.4f}")
