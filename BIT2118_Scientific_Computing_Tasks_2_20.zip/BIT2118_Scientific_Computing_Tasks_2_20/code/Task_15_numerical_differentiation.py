import numpy as np
import matplotlib.pyplot as plt

# Task 15: Numerical Differentiation
# Application: Estimate vehicle speed from GPS position measurements.

time = np.array([0, 1, 2, 3, 4, 5, 6], dtype=float)
position = np.array([0.0, 4.8, 10.2, 16.1, 22.7, 30.0, 38.0])

speed = np.zeros_like(position)

# Forward difference at the beginning.
speed[0] = (position[1] - position[0]) / (time[1] - time[0])

# Central differences for interior points.
for i in range(1, len(time) - 1):
    speed[i] = (
        position[i + 1] - position[i - 1]
    ) / (
        time[i + 1] - time[i - 1]
    )

# Backward difference at the end.
speed[-1] = (
    position[-1] - position[-2]
) / (
    time[-1] - time[-2]
)

for t, x, v in zip(time, position, speed):
    print(f"t={t:.0f}s, position={x:.1f}m, "
          f"estimated speed={v:.2f}m/s")

plt.plot(time, speed, marker="o")
plt.xlabel("Time (s)")
plt.ylabel("Estimated speed (m/s)")
plt.title("Speed estimated from GPS position data")
plt.grid(True)
plt.show()

# Parameter change example:
# Use a finer GPS sampling interval by interpolating position linearly.
fine_time = np.arange(0, 6.01, 0.5)
fine_position = np.interp(fine_time, time, position)
fine_speed = np.gradient(fine_position, fine_time)

print("\nEstimated speeds using 0.5-second spacing:")
for t, v in zip(fine_time, fine_speed):
    print(f"t={t:.1f}s: {v:.2f}m/s")
