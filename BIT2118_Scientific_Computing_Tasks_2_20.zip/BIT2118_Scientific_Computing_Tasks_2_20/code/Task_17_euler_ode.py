import numpy as np
import matplotlib.pyplot as plt

# Task 17: Ordinary Differential Equations — Euler Method
# Application: Newton's law of cooling.
# dT/dt = -k(T - T_ambient)

T_ambient = 25.0
T_initial = 90.0
k = 0.12
h = 1.0
end_time = 30.0

def cooling_rate(T):
    return -k * (T - T_ambient)

time = np.arange(0, end_time + h, h)
temperature = np.zeros_like(time)
temperature[0] = T_initial

for i in range(len(time) - 1):
    temperature[i + 1] = (
        temperature[i] + h * cooling_rate(temperature[i])
    )

# Exact solution for validation.
exact = T_ambient + (T_initial - T_ambient) * np.exp(-k * time)

print(f"Euler temperature after 30 min: {temperature[-1]:.2f} °C")
print(f"Exact temperature after 30 min: {exact[-1]:.2f} °C")
print(f"Final absolute error: "
      f"{abs(temperature[-1] - exact[-1]):.4f} °C")

plt.plot(time, temperature, marker="o", label="Euler")
plt.plot(time, exact, label="Exact solution")
plt.xlabel("Time (minutes)")
plt.ylabel("Temperature (°C)")
plt.title("Cooling of a hot object")
plt.legend()
plt.grid(True)
plt.show()

# Parameter change example: use h = 0.5 minutes.
h2 = 0.5
time2 = np.arange(0, end_time + h2, h2)
temperature2 = np.zeros_like(time2)
temperature2[0] = T_initial

for i in range(len(time2) - 1):
    temperature2[i + 1] = (
        temperature2[i] + h2 * cooling_rate(temperature2[i])
    )

exact_final = T_ambient + (T_initial - T_ambient) * np.exp(-k * end_time)
print(f"\nEuler result with h=0.5 min: {temperature2[-1]:.4f} °C")
print(f"Absolute error with h=0.5 min: "
      f"{abs(temperature2[-1] - exact_final):.6f} °C")
