import numpy as np

# Task 5: Matrix Algebra and Matrix Operations
# Application: Transform 2-D computer-graphics coordinates.

points = np.array([
    [0.0, 0.0],
    [1.0, 0.0],
    [1.0, 1.0],
    [0.0, 1.0]
])

angle = np.deg2rad(45)

rotation = np.array([
    [np.cos(angle), -np.sin(angle)],
    [np.sin(angle),  np.cos(angle)]
])

scale = np.array([
    [2.0, 0.0],
    [0.0, 1.5]
])

transformation = rotation @ scale
transformed_points = points @ transformation.T

print("Original points:\n", points)
print("\nTransformation matrix:\n", transformation)
print("\nTransformed points:\n", transformed_points)
print("\nDeterminant:", np.linalg.det(transformation))

# Verify the inverse exists.
if not np.isclose(np.linalg.det(transformation), 0):
    inverse = np.linalg.inv(transformation)
    recovered = transformed_points @ inverse.T
    print("\nInverse transformation:\n", inverse)
    print("\nRecovered points:\n", recovered)

# Parameter change example: change the rotation from 45° to 90°.
angle2 = np.deg2rad(90)
rotation2 = np.array([
    [np.cos(angle2), -np.sin(angle2)],
    [np.sin(angle2),  np.cos(angle2)]
])
transformation2 = rotation2 @ scale
print("\nTransformed points with 90° rotation:\n",
      points @ transformation2.T)
