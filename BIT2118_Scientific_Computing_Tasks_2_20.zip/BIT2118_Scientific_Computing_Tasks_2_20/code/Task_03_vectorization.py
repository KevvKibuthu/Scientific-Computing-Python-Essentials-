import numpy as np
import timeit

# Task 3: Mathematical Functions and Vectorization
# Application: One million network-latency measurements.

rng = np.random.default_rng(42)
latency_ms = rng.uniform(5, 250, 1_000_000)

def loop_version():
    squared = []
    for value in latency_ms:
        seconds = value / 1000.0
        squared.append(seconds ** 2)
    return squared

def vectorized_version():
    seconds = latency_ms / 1000.0
    return seconds ** 2

loop_time = timeit.timeit(loop_version, number=1)
vector_time = timeit.timeit(vectorized_version, number=3) / 3

result = vectorized_version()

print("First five squared latency values:", result[:5])
print(f"Loop time: {loop_time:.4f} s")
print(f"Vectorized time: {vector_time:.4f} s")
print(f"Approximate speed-up: {loop_time / vector_time:.1f}x")

# Parameter change example: use a different latency range.
changed_latency = rng.uniform(10, 300, 1_000_000)
changed_seconds = changed_latency / 1000.0
changed_squared = changed_seconds ** 2
print("First five results after changing the latency range:", changed_squared[:5])
