import numpy as np
from scipy.integrate import simpson

# Task 16: Numerical Integration
# Application: Estimate electrical energy from smart-meter readings.

time_hours = np.array([0, 2, 4, 6, 8, 10, 12], dtype=float)
power_kw = np.array([0.8, 1.0, 1.4, 1.8, 1.6, 1.2, 0.9])

energy_trapezoid = np.trapezoid(power_kw, time_hours)
energy_simpson = simpson(power_kw, x=time_hours)

print(f"Energy using trapezoidal rule: {energy_trapezoid:.3f} kWh")
print(f"Energy using Simpson's rule: {energy_simpson:.3f} kWh")
print(
    f"Difference between estimates: "
    f"{abs(energy_simpson - energy_trapezoid):.3f} kWh"
)

# Parameter change example:
# Increase every power reading by 10%.
power_changed = 1.10 * power_kw
changed_energy = simpson(power_changed, x=time_hours)
print(f"\nEnergy after increasing power readings by 10%: "
      f"{changed_energy:.3f} kWh")
