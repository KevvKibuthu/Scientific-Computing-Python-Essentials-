import numpy as np
from scipy.optimize import minimize

# Task 19: Numerical Optimization
# Application: Minimize cloud-server operating cost while meeting capacity.

# x = capacity units of Type A
# y = capacity units of Type B
# Cost: A = 12, B = 18
# Capacity: A = 100, B = 170
# Required capacity: at least 1000

def cost(z):
    x, y = z
    return 12 * x + 18 * y

def capacity_constraint(z):
    x, y = z
    return 100 * x + 170 * y - 1000

constraints = {
    "type": "ineq",
    "fun": capacity_constraint
}

bounds = [(0, None), (0, None)]

solution = minimize(
    cost,
    x0=[5, 3],
    method="SLSQP",
    bounds=bounds,
    constraints=constraints
)

x, y = solution.x

print("Optimization success:", solution.success)
print(f"Type A allocation: {x:.3f}")
print(f"Type B allocation: {y:.3f}")
print(f"Total capacity: {100*x + 170*y:.2f}")
print(f"Minimum planning cost: {solution.fun:.2f}")

# If whole servers are required, test nearby integer combinations.
best_integer = None

for a in range(0, 20):
    for b in range(0, 20):
        capacity = 100 * a + 170 * b

        if capacity >= 1000:
            total_cost = 12 * a + 18 * b

            if best_integer is None or total_cost < best_integer[0]:
                best_integer = (total_cost, a, b, capacity)

print("Best nearby integer solution:", best_integer)

# Parameter change example: increase required capacity to 1500.
def changed_capacity_constraint(z):
    x, y = z
    return 100 * x + 170 * y - 1500

changed_solution = minimize(
    cost,
    x0=[8, 5],
    method="SLSQP",
    bounds=bounds,
    constraints={"type": "ineq", "fun": changed_capacity_constraint}
)

print("\nWith required capacity increased to 1500:")
print(f"Type A allocation: {changed_solution.x[0]:.3f}")
print(f"Type B allocation: {changed_solution.x[1]:.3f}")
print(f"Cost: {changed_solution.fun:.2f}")
