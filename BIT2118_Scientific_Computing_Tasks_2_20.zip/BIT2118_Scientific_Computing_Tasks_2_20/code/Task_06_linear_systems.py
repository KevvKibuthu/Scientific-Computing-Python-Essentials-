import numpy as np

# Task 6: Solution of Systems of Linear Equations
# Application: Determine the number of two server types from CPU and memory totals.

# x = number of Type A servers
# y = number of Type B servers
# Type A: 4 CPU units, 8 GB memory
# Type B: 2 CPU units, 12 GB memory
# Total: 20 CPU units, 72 GB memory

A = np.array([
    [4.0, 2.0],
    [8.0, 12.0]
])

b = np.array([20.0, 72.0])

solution = np.linalg.solve(A, b)
residual = b - A @ solution

print(f"Type A servers: {solution[0]:.0f}")
print(f"Type B servers: {solution[1]:.0f}")
print("Verification A @ solution:", A @ solution)
print("Residual:", residual)
print("Residual norm:", np.linalg.norm(residual))

# Parameter change example: increase total CPU usage from 20 to 24.
b_changed = np.array([24.0, 72.0])
changed_solution = np.linalg.solve(A, b_changed)
print("\nAfter changing total CPU usage to 24:")
print(f"Type A: {changed_solution[0]:.2f}")
print(f"Type B: {changed_solution[1]:.2f}")
