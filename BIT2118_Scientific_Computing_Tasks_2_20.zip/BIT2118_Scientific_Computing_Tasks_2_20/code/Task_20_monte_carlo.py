import numpy as np
import matplotlib.pyplot as plt

# Task 20: Random Numbers and Monte Carlo Methods
# Application: Estimate probability of server overload.

rng = np.random.default_rng(42)

capacity = 1000.0
mean_demand = 850.0
std_demand = 120.0
N = 100_000

# Generate random demand scenarios.
demand = rng.normal(mean_demand, std_demand, N)

overloaded = demand > capacity
overload_probability = overloaded.mean()

print(f"Estimated overload probability: {overload_probability:.4%}")
print(f"Number of overload cases: {overloaded.sum()} out of {N}")

# Running probability to show convergence.
running_probability = (
    np.cumsum(overloaded) / np.arange(1, N + 1)
)

indices = np.unique(
    np.logspace(1, np.log10(N), 200).astype(int)
) - 1

plt.semilogx(
    indices + 1,
    running_probability[indices]
)
plt.xlabel("Number of simulations")
plt.ylabel("Estimated overload probability")
plt.title("Monte Carlo estimate of server-overload risk")
plt.grid(True)
plt.show()

# Parameter change example: increase capacity from 1000 to 1100.
capacity_changed = 1100.0
overloaded_changed = demand > capacity_changed
probability_changed = overloaded_changed.mean()

print(f"\nEstimated overload probability with capacity "
      f"{capacity_changed:.0f}: {probability_changed:.4%}")
