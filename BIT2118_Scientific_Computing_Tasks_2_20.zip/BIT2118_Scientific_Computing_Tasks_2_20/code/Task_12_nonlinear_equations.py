import numpy as np
from scipy.optimize import root

# Task 12: Polynomial and Nonlinear Equation Solving
# Application: Intersection of a circle and a parabola.
# Circle: x^2 + y^2 = 4
# Parabola: y = x^2 - 1

def equations(z):
    x, y = z
    return [
        x**2 + y**2 - 4,
        y - (x**2 - 1)
    ]

for guess in ([1.0, 1.0], [-1.0, 1.0]):
    solution = root(equations, guess)

    print("Initial guess:", guess)
    print("Intersection:", solution.x)
    print("Residuals:", equations(solution.x))
    print("Converged:", solution.success)
    print()

# Parameter change example:
# Change the circle radius from 2 to 3.
def equations_changed(z):
    x, y = z
    return [
        x**2 + y**2 - 9,
        y - (x**2 - 1)
    ]

print("After changing circle radius from 2 to 3:")
for guess in ([1.0, 1.0], [-1.0, 1.0]):
    solution = root(equations_changed, guess)
    print("Initial guess:", guess)
    print("Intersection:", solution.x)
    print("Residuals:", equations_changed(solution.x))
    print()
