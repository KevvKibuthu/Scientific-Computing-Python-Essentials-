# BIT 2118 Scientific Computing — Tasks 2–20

This folder contains one Python program for each task in the supplied BIT 2118
Scientific Computing Group Work document.

## Files

- Task_02_numpy_arrays.py — NumPy arrays and numerical computation
- Task_03_vectorization.py — Mathematical functions and vectorization
- Task_04_numerical_errors.py — Floating-point arithmetic and numerical errors
- Task_05_matrix_algebra.py — Matrix algebra and matrix operations
- Task_06_linear_systems.py — Systems of linear equations
- Task_07_gaussian_lu.py — Gaussian elimination and LU decomposition
- Task_08_iterative_linear.py — Iterative methods for linear systems
- Task_09_eigenvalues.py — Eigenvalues and eigenvectors
- Task_10_bisection_fixed_point.py — Bisection and fixed-point methods
- Task_11_newton_secant.py — Newton-Raphson and secant methods
- Task_12_nonlinear_equations.py — Polynomial and nonlinear equations
- Task_13_interpolation.py — Interpolation
- Task_14_curve_fitting.py — Curve fitting and approximation
- Task_15_numerical_differentiation.py — Numerical differentiation
- Task_16_numerical_integration.py — Numerical integration
- Task_17_euler_ode.py — ODEs using Euler's method
- Task_18_scipy_ode.py — Numerical ODE solution using SciPy
- Task_19_optimization.py — Numerical optimization
- Task_20_monte_carlo.py — Random numbers and Monte Carlo methods

## Installation

Recommended Python version: Python 3.10+

Install the required libraries:

    pip install numpy scipy matplotlib

## Running a task

From the `code` directory:

    python Task_02_numpy_arrays.py

Replace the filename with the task you want to run.

## Notes

Each program:
1. Implements the mathematical concept from the supplied brief.
2. Uses the example application described in the brief.
3. Prints the important numerical results.
4. Includes a small parameter/input-change example to demonstrate how changing
   an input affects the result, matching the group-work instruction.
5. Includes a graph where the task calls for visualization.
